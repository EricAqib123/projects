<?php


	$sno = 1;
    $worker_name = "Aqib Ali";
    $worker_age = 25;
    $worker_email = "aqibextension@gmail.com";
    $worker_phone_number = 03;
    $selectprofession = "pumbler";
    $worker_image = "RK.png";
     //filepath
  
     //data
    $data = "$sno,$worker_name ,$worker_age ,$worker_email $worker_phone_number,$selectprofession,$worker_image\n";
      $filePath = "user.txt";

   file_put_contents($filePath,$data,FILE_APPEND);
   echo "successfully";


$filePath = "user.txt";
if (file_exists($filePath)) {
    
    $fileData = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    foreach($fileData as $line)
    {
        $userData = explode(",", $line);
        $sno = $userData[0];
        $worker_name = $userData[1];
        $worker_age = $userData[2];
        $worker_email = $userData[3];
        $worker_phone_number = $userData[4];
        $selectprofession = $userData[5];
        $worker_image = $userData[6];
        echo $sno;
        echo "<br>";
        echo $worker_name;
        echo "<br>";
        echo $worker_age;
        echo "<br>";
        echo $worker_email;
        echo "<br>";
        echo $worker_phone_number;
        echo "<br>";
        echo $selectprofession;
        echo "<br>";
        if($worker_image !== ""){


        echo $worker_image;
    }
    }
}


?>