<?php 
    session_start();

// bookworker.php

// Retrieve worker information from URL parameters
$sno = $_GET['sno'];
$worker_name = $_GET['name'];
$worker_age = $_GET['age'];
$worker_email = $_GET['email'];
$worker_phone_number = $_GET['phone'];
$selectprofession = $_GET['profession'];
$worker_image = $_GET['image'];

// Now you can use these variables as needed, for example, you can display them on the page
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Book Worker</title>
	<style type="text/css">
		*{
			margin: 0px;
			padding: 0px;
			font-family: 'poppins', sans-serif;
			box-sizing: border-box;
		}
		a 
		{
			text-decoration: none;
			color:#5a5a5a;
		}
		img
		{
			cursor: pointer;
		}
		.flex-div
		{
			display: flex;
			align-items: center;
		}
		nav
		{
			padding: 10px 2%;
			justify-content: space-between;
			box-shadow: 0 0 10px rgb(0, 0, 0, 0.2);
			background:#fff;
			position: static;
			top:0;
			z-index: 10;
		}
		.nav_right a {
			width:25px;
			margin-right: 25px; 
		}
		.nav_left .menu-icon
		{
			width: 25px;
			margin-width:25px;
		}
		.nav_left .text
		{
           width: 130px;
		}
		.btn_search
		{
			width: 100px; 
			color: black;
			background-color:blue;
		}
		.dis
		{
			display: flex;


		}
		ul
		{
			text-align: center;
			display:flex;
			margin: 25px;
			margin-right: 25px;
			margin-left: 5px;

		}
		ul li
		{


		    text-decoration: none;
			list-style: none;
			color:black;
			width: 200px;
			padding:10px;
			margin: 3px;
			background-color: cyan;

		}
		li a 
		{

		    text-decoration: none;
			list-style: none;
			color:black;
			padding: 10px;
			margin: 3px;
		}
		li a:hover
		{
			color:blue;
			background-color: black;
		}
		.forms
		{
			display: block;
            width: 200px;
            margin: 30px;
            padding: 40px;
            border:px solid black;
		}

	</style>
</head>
<body>
<nav class="flex-div">
		<!--menu-->
		<div class="nav_left flex-div">
			<img  src="download.png" alt="image" class="menu-icon"><br>
			<p class="text">Worker-Online Hiring</p>
		</div>
		<!--body-->
		<div class="nav_middle flex-div">
			<form class="flex-div">
			<input type="search" name="">
			<input class="search" type="submit" name="" class="btn_search" value="Search Worker">
		</form>
		</div>
		<!--login-->
		<div class="nav_right flex-div">
			<a href="">login</a>
		</div>

	</nav>
	<!---sidebar-->
      <div class="dis">
		<ul>
			<li><a href="addworker.php">Add Worker</a></li>
			<li><a href="viewworker.php">View Worker</a></li>
			<li><a href="bookworker.php">Book Worker</a></li>
			<li><a href="rateworker.php?sno=<?=$sno;?>&name=<?=$worker_name;?>&age=<?=$worker_age;?>&email=<?=$worker_email;?>&phone=<?=$worker_phone_number;?>&profession=<?=$selectprofession;?>&image=<?=$worker_image;?>">Rate Workers</a></li>
		</ul>
	</div>

<!--PHP Data Collecting Chapter 1 in Book where client takes user data-->

	<h2>Book Worker</h2>
    <p>Worker Information:</p>
    <ul>

        <li><strong>SNO:</strong> <?=$sno;?></li>
        <li><strong>Name:</strong> <?=$worker_name;?></li>
        <li><strong>Age:</strong> <?=$worker_age;?></li>
        <li><strong>Email:</strong> <?=$worker_email;?></li>
        <li><strong>Phone:</strong> <?=$worker_phone_number;?></li>
        <li><strong>Profession:</strong> <?=$selectprofession;?></li>
        <li><strong>Image:</strong> <img src="<?=$worker_image;?>" alt="Worker Image" width="100" height="100"></li>
        <li><a href="confirmworker.php">Confirm Worker</li>
    </ul>

      
	
<br>

	<footer style="background: black; color:white">
		@copyright at Roll No: 2K20/CSEE/30 Along following name:Aqib Ali Buriro
	</footer>

</body>
</html>