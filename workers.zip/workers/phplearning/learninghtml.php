<?php
//use of isset method is to check whether the variable is exit or not
if (isset($_GET['btn_click'])) {
   $username =$_GET['username'];
   $userpass = $_GET['userpass']; 
   

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Forms Handling with php </title>
</head>
<body>
<h2>Forms Handling with PHP</h2>
entities- any company, office, addmission
-name
-age
-profession
-work experience
-profile image
etc...
type in input tag
text
email
password
month
week
date
range
radio
hidden
gobal variable in Php
$_GET['']
$_POST['']
$_SESSION['']
ETC..
//Get method 
<form action="learninghtml.php" method="get">
    <label for="Name">Name:</label>
    <input type="text" name="username"><!--name attribute is used to collect data from input field to php variable-->
    <label for="password">Password</label>
    <input type="password" name="userpass">
    <input type="submit" name="btn_click" value="Add"> 

</form>
<h2>
    <?php echo "Welcome to our Site:" . $username; }?>
</h2>

</body>
</html>