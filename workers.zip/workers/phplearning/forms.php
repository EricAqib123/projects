<?php
session_start();


if (isset($_POST['btn_click'])) {
	$username = $_POST['username'];
	$userpass = $_POST['userpass'];
	$confirmpass = $_POST['confirmpass'];
	$email = $_POST['useremail'];
	if($userpass==$confirmpass and !empty($email))
	{
         
         header("location:processforms.php");
         exit();
		
	      
    }
    else
    {
    	echo $error = "entites are missing";
    }
    $_SESSION['username'] = $username;
    $_SESSION['userpass'] = $userpass;
    $_SESSION['confirmpass'] = $confirmpass;
    $_SESSION['useremail'] = $email;  
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Forms handling in php</title>
</head>
<body>
	<form action="forms.php" method="post">
		username
		<input type="text" name="username">
		userpass
		<input type="password" name="userpass">
		confirm pass
		<input type="password" name="confirmpass">
		Email
		<input type="email" name="useremail" required>

		<input type="submit" name="btn_click" value="Add">
	</form>

</body>
</html>