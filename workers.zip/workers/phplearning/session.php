<?php
session_start();
if (isset($_SESSION['to_do_list'])) {
	$to_do = $_SESSION['to_do_list'];
}
else
{
	$to_do = [];
}
//different add in array
if (isset($_POST['btn'])) {
	$name =  $_POST['task'];
	$age = $_POST['task2'];
    
    $list = [ 
                 'name' => $name,
                 'age'=> $age


    ];
     $_SESSION['to_do_list']= $list;
}
//add
if (isset($_POST['task']) and !empty($_POST['task'])) {
	$task = $_POST['task'];
	$to_do[$task] = $task;
	$_SESSION['to_do_list'] =$to_do;
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>session</title>
</head>
<body>


<form action="session.php" method="post">
	<input type="text" name="task">
	<input type="text" name="task2">
	<input type="submit" name="btn" value="Add">
		<h2>Data showing</h2>

        <table>
        	<tr>
        		<td>name</td>
        		<td>age</td>
        	</tr>
        	 <?php if(!empty($to_do)): foreach($to_do as $task):?>
        	 		<tr>
        		<td><div><?=$task;?></div></td>
        		<td></td>
        	</tr>
        	 <?php endforeach; endif;?>
        </table>



        <ul>
            <?php if(!empty($to_do)): foreach($to_do as $task):?>
            <li><div><?=$task;?><a href="session.php?task=<?=$task;?>">Delete</a><div></li>
            <?php endforeach; endif;?>
        </ul>
</form>
</body>
</html>