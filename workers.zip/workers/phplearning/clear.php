<?php
session_start();
 $_SESSION['storeworker'][] = $worker; // Append the new worker to the array	
// Clear all data from the 'storeworker' array in the session
unset($_SESSION['storeworker']);

// Optionally, you can also destroy the entire session
// session_destroy();

// Redirect to the same or another page
header("Location: index.php");
exit();
?>
