<?php
session_start();

if (!isset($_SESSION['workers'])) {
    $_SESSION['workers'] = [];
}

if (isset($_POST['add_worker'])) {
    $sno = $_POST['sno'];
    $worker_name = $_POST['worker_name'];
    $worker_age = $_POST['worker_age'];
    $worker_email = $_POST['worker_email'];
    $worker_phone_number = $_POST['worker_phone_number'];
    $selectprofession = $_POST['selectprofession'];
    $worker_image = $_POST['worker_image'];

    $worker = [
        'sno' => $sno,
        'worker_name' => $worker_name,
        'worker_age' => $worker_age,
        'worker_email' => $worker_email,
        'worker_phone_number' => $worker_phone_number,
        'selectprofession' => $selectprofession,
        'worker_image' => $worker_image,
    ];

    $_SESSION['workers'] = $worker;
}
if (isset($_SESSION['workers']) and !empty($_SESSION['workers'])) {
    if(isset($_POST['workers'])){
    $worker = $_POST['workers'];
    $workers[$worker] = $worker;
    $_SESSION['workers'] = $workers;
}
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Worker</title>
</head>
<body>

<!---sidebar-->
<div class="dis">
    <ul>
        <li><a href="addworker.php">Add Worker</a></li>
        <li><a href="viewworker.php">View Worker</a></li>
        <li><a href="bookworker.php">Book Worker</a></li>
        <li><a href="rateworker.php">Rate Workers</a></li>
    </ul>
</div>

<!--PHP Data Collecting Chapter 1 in Book where client takes user data-->
<div class="forms">
    <form action="face.php" method="post" enctype="multipart/form-data">
        <label>Sno</label><br>
        <input type="text" name="sno"><br>
        <label>Worker Name:</label><br>
        <input type="text" name="worker_name" id="worker_name" required><br>
        <label> Worker Age:</label><br>
        <input type="number" name="worker_age" id="worker_age" required><br>
        <label> Worker Email- If Possible: </label><br>
        <input type="email" name="worker_email" id="worker_email"><br>
        <label>Worker Phone Number:</label><br>
        <input type="number" name="worker_phone_number" id="worker_phone_number" required><br>
        <label>Worker Profession: </label><br>
        <select name="selectprofession" value="Profession Category" required>
            <option value="Electrician">Electrician</option>
            <option value="Plumber">Plumber</option>
            <option value="Painter">Painter</option>
        </select><br>
        <label>Worker Profile Image:</label><br>
        <input type="file" name="worker_image" id="worker_image" required><br>
        <input type="submit" name="add_worker" value="Add Worker">
    </form>
</div>

<!--Data-->
<h2>Data Showing:</h2>
<table>
    <tr>
        <td>SNO</td>
        <td>Worker_Name</td>
        <td>Worker_Age</td>
        <td>Worker_Email</td>
        <td>Worker Phone Mobile</td>
        <td>Worker Profession</td>
        <td>Worker Image</td>
    </tr>
        <?php  foreach($worker as $items): ?>
    <tr>
       <td><div><?=$_SESSION['workers']['sno']?></div></td>
    </tr>
     <?php endforeach;?>
</table>

</body>
</html>
