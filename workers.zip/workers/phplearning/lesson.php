<?php
  
  if (isset($_POST['btn'])) {
  	
  	$username = $_POST['username'];
  	$password = $_POST['userpass'];
    $image =  $_POST['userimage'];
    //method
    //move_uploaded_file($_FILES['userimage']['tmp_name'], "images/" .$_FILES['userimage']['name']);

  	echo "Welcome:" . '<br>'. $username ."<br>";
    echo '<img src="images/'. $image.'" alt="imagenotfound" height="100" width="100">';
  }


?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Posting</title>
</head>
<body>

  <form method="post">
    <label>Write your Post:</label><br>
    <input type="text" name="postfeed"><br>
    <input type="submit" name="is_post" value="Add Post">
    
  </form>

</body>
</html>