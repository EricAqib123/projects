<?php
session_start();


?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Dashboard</title>
</head>
<body>
	<h2>Welcome to our Posting Site MR :</h2>
    <?php echo var_dump($_SESSION['username']);?>
	<form action="processforms.php" method="post">
		Write your Post:<br>
		<textarea 4 name="post"></textarea><br>
		<input type="submit" name="submit_post" value="Add Post">
	</form>
	<?php 
	if(isset($_POST['submit_post']))
	{
		$post = $_POST['post'];
         echo "Word Count:" .strlen($post); 
         echo "<br>";
		if(strlen($post) >=50)
		{
			echo "please limt your paragraph with 500";
		}
		else
		{
			//echo $post;
	?>
	<h2></h2>
	<p style="background: grey; color:white">
		<?=$post;?>

	</p>
	<?=date("l jS \of F Y h:i:s A");?>
	<?php
       }
       }
 
	?>
	

</body>
</html>