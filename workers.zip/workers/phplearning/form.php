<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Forms - Get and Post Methods </title>
</head>
<body>

	<form action="lesson.php" method="post">
		username:
		<input type="text" name="username"><br>
		Password:
		<input type="password" name="userpass"><br>
		Profile Image:
		<input type="file" name="userimage"><br>

		<input type="submit" name="btn" value="Login">
	</form>


</body>
</html>
