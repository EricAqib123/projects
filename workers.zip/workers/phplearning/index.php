<?php
session_start();

if (isset($_POST['add_worker'])) {
    $worker = array(
        'sno' => $_POST['sno'],
        'workername' => $_POST['worker_name'],
        'worker_age' => $_POST['worker_age'],
        'worker_email' => $_POST['worker_email'],
        'worker_phone_number' => $_POST['worker_phone_number'],
        'selectprofession' => $_POST['selectprofession'],
        'worker_image' => $_FILES['worker_image']['name'], // Use $_FILES for file uploads
    );

    $_SESSION['storeworker'][] = $worker; // Append the new worker to the array
    move_uploaded_file($_FILES['worker_image']['tmp_name'], "images/" . $_FILES['worker_image']['name']);
}
// Delete logic
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['sno'])) {
    $snoToDelete = $_GET['sno'];

    foreach ($_SESSION['storeworker'] as $key => $worker) {
        if ($worker['sno'] == $snoToDelete) {
            unset($_SESSION['storeworker'][$key]);
            $_SESSION['storeworker'] = array_values($_SESSION['storeworker']);
            break; // exit the loop after deletion
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Worker</title>
</head>

<body>

    <!-- Sidebar -->
    <div class="dis">
        <ul>
            <!-- Your sidebar links -->
        </ul>
    </div>

    <!-- HTML Form -->
    <div class="forms">
        <form action="index.php" method="post" enctype="multipart/form-data">
        	<label>Sno</label><br>
		<input type="text" name="sno"><br>
		<label>Worker Name:</label><br>
		<input type="text" name="worker_name" id="worker_name" required><br>
		<label> Worker Age:</label><br>
		<input type="number" name="worker_age" id="worker_age" required><br>
		<label> Worker Email- If Possible: </label><br>
		<input type="email" name="worker_email" id="worker_email"><br>
		<label>Worker Phone Number:</label><br>
		<input type="number" name="worker_phone_number" id="worker_phone_number" required><br>
		<label>Worker Profession: </label><br>
		<select name="selectprofession" value="Profession Category" required>
			<option value="Electrican">Electrican</option>
			<option value="Pumbler">Pumbler</option>
			<option value="Painter">Painter</option>
		</select><br>
		<label>Worker Profile Image:</label><br>
		<input type="file" name="worker_image" id="worker_image" required><br>
		<input type="submit" name="add_worker" value="Add Workers">
        </form>
    </div>

    <!-- Data Display -->
    <h2>Data Showing:</h2>
    <table>
    	<tr>
    		<td>Sno</td>
    		<td>Worker Name</td>
    		<td>Worker Age</td>
    		<td>Worker Email</td>
    		<td>Worker Phone Number</td>
    		<td>Select Profession</td>
    		<td>Worker Image</td>
    		
    	</tr>
        <!-- Display worker data here using a loop -->
        <?php foreach ($_SESSION['storeworker'] as $worker) : ?>
            <tr>
                <td><?= $worker['sno']; ?></td>
                <td><?= $worker['workername']; ?></td>
                <td><?= $worker['worker_age']; ?></td>
                <td><?= $worker['worker_email']; ?></td>
                <td><?= $worker['worker_phone_number']; ?></td>
                <td><?= $worker['selectprofession']; ?></td>
                <td><?= '<img src="images/' . $worker['worker_image'] . '" width="100" height="100">'; ?></td>
                <td><a href="index.php?action=delete&sno=<?= $worker['sno'] ?>">Delete</a></td>
            </tr>
        <?php endforeach; ?>
    </table>
    <a href="clear.php">Clear list</a>
</body>

</html>
