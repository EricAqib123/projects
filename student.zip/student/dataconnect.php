<?php

$servername = "localhost";
$name = "pts";
$pass = "";
$db = "pts";

$conn = new mysqli($servername,$name,$pass,$db);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "successfull";








?>