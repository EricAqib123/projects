
<?php
  session_start();
  include "dataconnect.php";
  $serial_id = isset($_SESSION['sno'])? $_SESSION['sno']:null;
if(isset($_POST['student_process_btn']))
{
    //$std_id = isset($_POST['userid']) ? $_POST['userid'] : null;
    //$pass = isset($_POST['userpass']) ? $_POST['userpass'] : null;
    $userid = mysqli_real_escape_string($conn, $_POST['userid']);
    $userpass = mysqli_real_escape_string($conn, $_POST['userpass']);

    $checkbox = isset($_POST['usercheck']) ? $_POST['usercheck'] : null;
    $query = "SELECT * FROM student WHERE std_id = '$userid'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            //$hashed_password = $row['student_pass']; // replace with your actual column name

            // Verify the password
            if ($userpass) {
                // Password is correct, start a new session
                $_SESSION['userid'] = $userid;

                // Redirect to a secure page
                header("Location:onlineapplicationform.php");
                exit();
            } else {
                // Invalid password
                echo "Invalid password";
            }
        } else {
            // User not found
            echo "User not found";
        }
    } else {
        // Query failed
        echo "Query failed: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}
    // if(isset($_POST['userid']) || isset($_POST['userpass']))
    // {
    //     $check = mysqli_real_escape_string($conn, $std_id . $pass);
    //     $query = "SELECT * FROM student WHERE std_id LIKE '%$check%' OR student_pass LIKE '%$check%'";
    //     $query_run = mysqli_query($conn, $query);

    //     // Assuming you want to check if there is a matching record in the database
    //     if(mysqli_num_rows($query_run) > 0)
    //     {
    //         // Valid credentials, redirect to the desired page
    //         header("location: onlineapplicationform.php");
    //     }
    //     else
    //     {
    //         // Invalid credentials, handle accordingly (e.g., display an error message)
    //         header("location:index.php");
    //     }
    // }

?>
