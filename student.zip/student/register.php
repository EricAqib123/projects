<?php
  session_start();
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Students Application Portal System</title>
    <!-- Add Bootstrap CSS link -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- Add custom CSS -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
        }

        .header {
            background-color: #007bff;
            color: #fff;
            text-align: center;
            padding: 10px;
        }

        .forms {
            max-width: 400px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        .forms label {
            font-weight: bold;
        }

        .forms input[type="text"],
        .forms input[type="email"],
        .forms input[type="password"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }

        .forms input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        .forms input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="header">
        <p>Students Application Portal System</p>
    </div>

    <br>
     <center><h2>Registeration- For online application portal</h2></center>
    <div class="forms">
        <form action="process_register.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="username">Name:</label>
                <input type="text" class="form-control" name="name" required>
             </div>
              <div class="form-group">
                <label for="lname">Last Name:</label>
                <input type="text" class="form-control" name="lastname" required>
             </div>
              <div class="form-group">
                <label for="national">National ID Card:</label>
                <input type="text" class="form-control" name="nationalid" required>
             </div>
              <div class="form-group">
                <label for="fname">Father's Name:</label>
                <input type="text" class="form-control" name="fathername" required>
             </div>
              <div class="form-group">
                <label for="country">Country:</label>
                <input type="text" class="form-control" name="country" required>
             </div>
             <div class="form-group">
                <label for="select">Select Course:</label>
                <select name="select" class="form-control">
                    <option>Electronic</option>
                    <option>Computing</option>
                </select>
             </div>

              <div class="form-group">
                <label for="academic">Academic Qualification</label><br>
                <label for="matrix">Matrix</label>
                <input type="file" class="form-control" name="matrix" required>
                <label for="inter">Intermediate</label>
                <input type="file" class="form-control" name="inter" required>
                <label for="degree">BS/MS/MPHILL/PHD</label>
                <input type="file" class="form-control" name="degree">
                <label for="idfront">ID CARD FRONT</label>
                <input type="file" class="form-control" name="front" required>
                <label for="idback">ID CARD BACK</label>
                <input type="file" class="form-control" name="back" required>
             </div>
            <input type="submit" class="btn btn-primary" name="student_register_btn" value="Register">
             <br>
            
        </form>
    </div>
    <br>

    
    <!-- Add Bootstrap JS and Popper.js script links -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
