function login() {
    var username = document.getElementById('loginUsername').value;
    var password = document.getElementById('loginPassword').value;

    // Perform login validation (you can replace this with your own logic)
    if (username === 'demo' && password === 'password') {
        alert('Login successful!');
    } else {
        alert('Invalid username or password. Please try again.');
    }
}

function signup() {
    var username = document.getElementById('signupUsername').value;
    var password = document.getElementById('signupPassword').value;

    // Perform signup logic (you can replace this with your own logic)
    alert('Signup successful!');

    // Optionally, you can redirect the user to the login form after successful signup
    document.getElementById('loginForm').style.display = 'block';
    document.getElementById('signupForm').style.display = 'none';
}
