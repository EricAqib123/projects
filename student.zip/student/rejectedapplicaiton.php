<?php
  session_start();
  include "dataconnect.php";
 //assessing student id
  $std_id = isset($_SESSION['userid']) ? $_SESSION['userid'] : null;
 $serial_id = isset($_SESSION['sno'])? $_SESSION['sno']:null;

if ($std_id) {
    $query = "SELECT * FROM student WHERE std_id = '$std_id'";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die("Query failed: " . mysqli_error($conn) . "<br>Query: " . $query);
    }

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $userimage = $row['student_image'];
        $username = $row['student_name'];
    } else {
        die("Student not found in the database");
    }
} else {
    die("Invalid student ID");
}
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>rejected application</title>
    <!-- Add Bootstrap CSS link -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- Add custom CSS -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
        }

        .header {
            background-color: #007bff;
            color: #fff;
            text-align: center;
            padding: 10px;
        }
         .navbar {
            background-color: #333;
        }

        .navbar a, .navbar select {
            color: white;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }

        .circular-image {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
        
    </style>
</head>
<body>
    <div class="header">
        <p>Students Application Portal System</p>
    </div>

    <br>
     <div class="container-fluid">
    <div class="navbar">
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="onlineapplicationform.php">Home</a>
            </li>
            <li class="nav-item">
                <span class="nav-link" style="color:white">Status
                  <?php include "status.php";  ?>
                </span>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="history.php">History</a>
            </li>
            <li class="nav-item">
                
                <img src="<?php echo $userimage; ?>" alt="Profile Image" class="circular-image">
                   <span style="color:white"> <?php echo $username; ?></span>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>
</div>
    
    <br>

    
    <!-- Add Bootstrap JS and Popper.js script links -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>

