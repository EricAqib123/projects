<?php

function upload($image,$dir)
{
   if(move_uploaded_file($image,$dir))
   {
   	 echo "successfully uploaded"; 
   }
   else
   {
   	echo " failed uploded";
   }

}









?>