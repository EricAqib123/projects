<?php
session_start();
include "dataconnect.php";
$std_id = isset($_SESSION['userid'])?$_SESSION['userid']:null;
 $serial_id = isset($_SESSION['sno'])? $_SESSION['sno']:null;
if(isset($_POST['student_submit_btn']))
{
    $sno =  isset($_POST['sno'])?$_POST['sno']:null;
	$studentname = isset($_POST['username'])?$_POST['username']:null;
	$email = isset($_POST['useremail'])?$_POST['useremail']:null;
	$std_id = isset($_POST['userid'])?$_POST['userid']:null;
 	//image
	$image  = isset($_FILES['userimage']['name'])?$_FILES['userimage']['name']:null;
	$img_tmp = $_FILES['userimage']['tmp_name'];
	$dir = "uploads/" . $image;
	if(move_uploaded_file($img_tmp, $dir))
	{
		echo "images uploaded successfully";
	}
	else
	{
		echo "failed at uploading";
	}
	$pass = isset($_POST['userpass'])?$_POST['userpass']:null;
	$cpass = isset($_POST['usercpass'])?$_POST['usercpass']:null;
//inserting all informaiton in database

$ins = mysqli_query($conn,"INSERT INTO student(`student_id`,`student_name`, `student_email`, `std_id`, `student_image`, `student_pass`, `student_cpass`) VALUES ('$sno','$studentname','$email','$std_id','$dir','$pass','$cpass')");

if(!$ins)
{ 
	echo mysqli_error($conn);
}
else
{
	 echo "record added successfully";
}

header("location:register.php");
}



//header("location:register.php");	




?>