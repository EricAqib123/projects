<?php
  session_start();
  include "dataconnect.php";
  $std_id = isset($_SESSION['userid'])?$_SESSION['userid']:null;
  $serial_id = isset($_SESSION['sno'])?$_SESSION['sno']:null;
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Students Application Portal System</title>
    <!-- Add Bootstrap CSS link -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- Add custom CSS -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
        }

        .header {
            background-color: #007bff;
            color: #fff;
            text-align: center;
            padding: 10px;
        }

        .forms {
            max-width: 400px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        .forms label {
            font-weight: bold;
        }

        .forms input[type="text"],
        .forms input[type="email"],
        .forms input[type="password"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }

        .forms input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        .forms input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="header">
        <p>Students Application Portal System</p>
    </div>

    <br>
     <center><h2>Login</h2></center>
    <div class="forms">
        <form action="login.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="username">Student Id:</label>
                <input type="text" class="form-control" name="userid" required>
           
            <div class="form-group">
                <label for="userpass">Password:</label>
                <input type="password" class="form-control" name="userpass" required>
            </div>
               <div class="form-group">
                <label for="check">Remember:</label>
                <input type="checkbox" class="form-control" name="usercheck" required>
            </div>
            <input type="submit" class="btn btn-primary" name="student_process_btn" value="Login">
             <br>
             <p>Login in system, if not Signup <a href="signup.php">Signup</a></p>
        </form>
    </div>
    <br>

    
    <!-- Add Bootstrap JS and Popper.js script links -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>

