
 <form action="process_status.php" method="post" enctype="multipart/form-data">
 <select name="status" class="form-control">
                        <option><a href="approvedapplication.php">Approved</a></option>
                        <option><a href="processingapplication.php">Processing</a></option>
                        <option><a href="rejectedapplicaiton.php">Rejected</a></option>
                        <option><a href="inwaitingapplication.php">In-Waiting</a></option>
                    </select>
                    <input type="submit" name="btn" value="status">
                    </form>


