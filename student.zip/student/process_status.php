<?php
session_start();
  include "dataconnect.php"; 
if (isset($_POST['status'])) {
    $selected_status = isset($_POST['status']) ? $_POST['status'] : null;

    // Check if the status already exists
    $checkQuery = "SELECT * FROM status WHERE status_name = '$selected_status'";
    $checkResult = mysqli_query($conn, $checkQuery);

    if (!$checkResult) {
        echo mysqli_error($conn);
    } else {
        if (mysqli_num_rows($checkResult) > 0) {
            // Status already exists, retrieve information
            $row = mysqli_fetch_assoc($checkResult);
            $status_id = $row['status_id'];
            // Add more information retrieval as needed

            //echo "Status already exists with ID: $status_id";
            // Add more actions or redirect if needed
        } else {
            // Status does not exist, insert new status
            $ins = mysqli_query($conn, "INSERT INTO status (`status_name`) VALUES ('$selected_status')");

            if (!$ins) {
                echo mysqli_error($conn);
            } else {
                echo "Record added successfully";
            }

            // Redirect based on the selected status
            switch ($selected_status) {
                case 'Approved':
                    header("Location: approvedapplication.php");
                    break;
                case 'Processing':
                    header("Location: processingapplication.php");
                    break;
                case 'Rejected':
                    header("Location: rejectedapplication.php");
                    break;
                case 'In-waiting':
                    header("Location: inwaitingapplication.php");
                    break;
                default:
                    // Handle other cases or show an error
                       echo "Invalid status selected";
                    break;
            }
        }
    }
}

?>
