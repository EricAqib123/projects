<?php
session_start();
include "dataconnect.php";
include "fun.php";
$serial_id = isset($_SESSION['sno'])? $_SESSION['sno']:null;

if (isset($_POST['student_register_btn'])) {
   //$std_id = isset($_SESSION['userid'])?$_SESSION['userid']:null;	
	$name = isset($_POST['name'])?$_POST['name']:null;
	$lname = isset($_POST['lastname'])?$_POST['lastname']:null;
	$nationalid = isset($_POST['nationalid'])?$_POST['nationalid']:null;
	//asking fathername
	$fname = isset($_POST['fathername'])?$_POST['fathername']:null;
	$country = isset($_POST['country'])?$_POST['country']:null;
	//mention your course
	$selectCourse = isset($_POST['select'])?$_POST['select']:null;

	//checking images for matrix
	$matrix_img = isset($_FILES['matrix']['name'])?$_FILES['matrix']['name']:null;
    $matrix_tmp = $_FILES['matrix']['tmp_name'];
    $dest = "upload/" . $matrix_img;
    if(file_exists($matrix_tmp))
    {
    	upload($matrix_tmp,$dest);
    }
    //for intermediate

    $inter_img = isset($_FILES['inter']['name'])?$_FILES['inter']['name']:null;
    $inter_tmp = $_FILES['inter']['tmp_name'];
    $exp = "upload/" . $inter_img;

    upload($inter_tmp,$exp);
    // if (file_exists($inter_tmp)) {
    // 	upload($inter_tmp,$exp);
    // }

    //bsdegree
    $bs_img = isset($_FILES['degree']['name'])?$_FILES['degree']['name']:null;
    $bs_tmp = $_FILES['degree']['tmp_name'];
    $bs_dir = "upload/" . $bs_img;

    if(file_exists($bs_tmp))
    {
    	upload($bs_tmp,$bs_dir);
    }
    //idfront
    $idfront_img = isset($_FILES['front']['name'])?$_FILES['front']['name']:null;
    $idfront_tmp = $_FILES['front']['tmp_name'];
    $idfront_dir = "upload/" . $idfront_img;

    if(file_exists($idfront_tmp))
    {
    	upload($idfront_tmp,$idfront_dir);
    }
    //idback
    $idback_img = isset($_FILES['back']['name'])?$_FILES['back']['name']:null;
    $idback_tmp = $_FILES['back']['tmp_name'];
    $idback_dir = "upload/" . $idback_img;

    if (file_exists($idback_tmp)) {
    	
    	upload($idback_tmp,$idback_dir);
    }
    $status = isset($_POST['status'])?$_POST['status']:null;
   $ins = mysqli_query($conn,"INSERT INTO register (`register_name`, `register_lname`, `register_nationalid`, `register_fname`, `register_country`, `register_course`, `register_matrix`, `register_inter`, `register_degree`, `register_idfront`, `register_idback`) VALUES ('$name','$lname','$nationalid','$fname','$country','$selectCourse','$dest','$exp','$bs_dir','$idfront_dir','$idback_dir')");
   if(!$ins)
{ 
    echo mysqli_error($conn);
}
else
{
     echo "record added successfully";
}
header("location:index.php");
}

   

























?>