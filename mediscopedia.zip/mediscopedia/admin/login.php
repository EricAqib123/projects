<?php
// Start session
session_start();

// Simulate database records
$admin_credentials = [
    'admin' => password_hash('adminpassword', PASSWORD_DEFAULT), // Hashed password
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    if (isset($admin_credentials[$username]) && password_verify($password, $admin_credentials[$username])) {
        // Successful login
        $_SESSION['username'] = $username;
        header('Location: dashboard.php');
        exit();
    } else {
        // Invalid login
        $error_message = "Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login Result</title>
</head>
<body>
    <?php if (isset($error_message)) echo "<p>$error_message</p>"; ?>
    <a href="index.php">Go back to login</a>
</body>
</html>
