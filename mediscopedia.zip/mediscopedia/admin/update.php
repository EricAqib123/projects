<?php 
session_start();
 include "dataconnect.php"; ?>
<!DOCTYPE html>
<html>
<head>
	<title>Update Medicine</title>
	<link rel="stylesheet" type="text/css" href="med.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	

</head>
<body>
	<div class="logo w3-card-4 ">
      <img src="logo.png" alt="text" width="100" height="100">
      <a href="admin.php" style="text-align:center; float:right;"class="w3-bar-item w3-button w3-black"> logout </a>
	</div>
	<!--navbar-->
	 <?php include "navbar.php" ?>
	<br>
	<span>Update</span>
	<br>
	<form action="chag.php" method="post">
		<center>
    <!--   <label>Category</label><br>
      <select value="category">
        <option value="painkiller" name="getpainkiller">Pain Killer</option>
      </select><br> -->
		 <label class="w3-text-blue" style="font-size:25px;font-family:serif; ">Sno:</label><br>
        <input type="text" class="w3-border"  style="border:1px solid blue; width:500px;"name="sno"><br>
        <label class="w3-text-blue" style="font-size:25px;font-family:serif; ">Generic Name:</label><br>
        <input type="text" class="w3-border" style="border:1px solid blue; width:500px;" name="generic_name"><br>
        <label class="w3-text-blue" style="font-size:25px;font-family:serif; " >Medicine Name:</label><br>
        <input type="text" class="w3-border" style="border:1px solid blue; width:500px;" name="medicine_name"><br>
       <label class="w3-text-blue" style="font-size:25px;font-family:serif; ">National Drug Code:</label><br>
       <input type="text" class="w3-border" style="border:1px solid blue; width:500px;"  name="national_drug_code"><br>
      <label class="w3-text-blue" style="font-size:25px;font-family:serif; ">To Which Age Group:</label><br>
        <input type="text" class="w3-border" style="border:1px solid blue; width:500px;" name="twag"><br>
      <label class="w3-text-blue" style="font-size:25px;font-family:serif; ">Gram of Medicine:</label><br>
        <input type="text" class=" w3-border" style="border:1px solid blue; width:500px;" name="medicine_gram"><br>
      <label class="w3-text-blue" style="font-size:25px;font-family:serif; ">Formuale of Medicine:</label><br>
        <input type="text" class="w3-border" style="border:1px solid blue; width:500px;" name="medicine_formulae"><br>
      <label class="w3-text-blue" style="font-size:25px;font-family:serif; ">Company Of Medicine:</label><br>
        <input type="text" class="w3-border" style="border:1px solid blue; width:500px;" name="medicine_company"><br>
      <label class="w3-text-blue" style="font-size:25px;font-family:serif; ">Alternate of Medicine:</label><br>
        <input type="text" class="w3-border" style="border:1px solid blue; width:500px;" name="medicine_alt"><br>
      <label class="w3-text-blue" style="font-size:25px;font-family:serif; ">To Which Illness:</label><br>
        <input type="text" class="w3-border" style="border:1px solid blue; width:500px;" name="medicine_illness"><br>
      <label class="w3-text-blue" style="font-size:25px;font-family:serif; ">To Which Disease:</label><br>
        <input type="text" class="w3-border" style="border:1px solid blue; width:500px;" name="medicine_disease"><br>
      <label class="w3-text-blue" style="font-size:25px;font-family:serif; ">Dosage Of Medicine:</label><br>
        <input type="text" class="w3-border" style="border:1px solid blue; width:500px;" name="medicine_dosge"><br>
        <label class="w3-text-blue" style="font-size:25px;font-family:serif; ">Forms of Medicine/Dosage Form</label><br>
      <input type="text" class="w3-border" style="border:1px solid blue; width:500px;" name="anyinput"><br>
      <!-- <label class="w3-text-blue"style="font-size:25px;font-family:serif; ">Route of Administration</label><br>
      <select class="w3-border" style="border:1px solid blue; width:500px; color:black" width="100">
        <option name="oral">oral</option>
        <option name="injection">injection</option>
        <option name="liquids">liquids</option>
      </select><br> -->
      <label class="w3-text-blue" style="font-size:25px;font-family:serif; ">Side Effect:</label><br>
      <input type="textarea" class=" w3-border" style="border:1px solid blue; width:500px;"name="side_effect"><br>
      <label class="w3-text-blue"style="font-size:25px;font-family:serif; ">Warnings and Precautions:</label><br>
      <input type="textarea" class="w3-border" style="border:1px solid blue; width:500px;" name="warnings"><br>
      <label class="w3-text-blue" style="font-size:25px;font-family:serif; ">Contraindications:</label><br>
      <input type="textarea" class="w3-border" style="border:1px solid blue; width:500px;" name="Contraindications"><br>
      <label class="w3-text-blue" style="font-size:25px;font-family:serif; ">Mechanism Of Action:</label><br>
      <input type="textarea" class=" w3-border"  style="border:1px solid blue; width:500px;" name="mechanism"><br>
      <label class="w3-text-blue" style="font-size:25px;font-family:serif; ">Pharmacodynamcis:</label><br>
      <input type="textarea" class=" w3-border" style="border:1px solid blue; width:500px;" name="pharmacodynamcis"><br>
      <label class="w3-text-blue" style="font-size:25px;font-family:serif; ">Storage and Handling:</label><br>
      <input type="textarea"  class="w3-border" style="border:1px solid blue; width:500px;" name="strhandle"><br>
    
      <label class="w3-text-blue" style="font-size:25px;font-family:serif; ">Medicine Image:</label><br>  
        <input type="file" class="w3-border" style="border:1px solid blue; width:500px; background-color:lightblue;" name="upload"><br><br>
   <input type="submit"  class="w3-button w3-yellow"name="btn" value="update">
      
     
		</center>
</form>


</body>
</html>
