<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="med.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	

</head>
<body>
	<div class="logo w3-card-4 ">
      <img src="logo.png" alt="text" width="100" height="100">
      <a href="admin.php" style="text-align:center; float:right;"class="w3-bar-item w3-button w3-black"> logout </a>
	</div>
  <!--navbar-->
 <?php include "navbar.php" ?>


</body>
</html>
<?php
include "dataconnect.php";

$email= isset($_POST['username']);
$pass = isset($_POST['password']);

if(isset($_POST['login']))
{
    if($email==$username && $pass==$password)
    {
    	echo "login sucessfull";
    }
}

?>