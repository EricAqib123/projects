<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Slider</title>
    <link rel="stylesheet" href="styles.css">
    <style type="text/css">
        body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
}

.slider-container {
    width: 100%;
    overflow: hidden;
}

.slider {
    display: flex;
    transition: transform 0.5s ease;
}

.slider img {
    width: 100%;
    height: auto;
}

    </style>
</head>
<body>
    <div class="slider-container">
        <div class="slider">
            <img src="images/1.jpeg" alt="Image 1">
            <img src="images/3.jpeg" alt="Image 2">
            <img src="images/download (2).jpeg" alt="Image 3">
        </div>
        
    </div>
    <script>
        const slider = document.querySelector(".slider");
const images = document.querySelectorAll(".slider img");

let currentIndex = 0;

function nextSlide() {
    currentIndex = (currentIndex + 1) % images.length;
    updateSlider();
}

function prevSlide() {
    currentIndex = (currentIndex - 1 + images.length) % images.length;
    updateSlider();
}

function updateSlider() {
    const translateX = -currentIndex * 100;
    slider.style.transform = `translateX(${translateX}%)`;
}

setInterval(nextSlide, 3000); // Change slide every 3 seconds

// You can also add event listeners to buttons or use other methods to control the slider.

    </script>
</body>
</html>
