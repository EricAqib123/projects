<div class="w3-bar-block w3-green">
      <ul>
      	<li><a href="add.php" class="w3-bar-item w3-button w3-black"> Add Medicine </a></li>
      	<li><a href="update.php" class="w3-bar-item w3-button"> Update Medicine </a></li>
      	<li><a href="del.php"class="w3-bar-item w3-button"> Delete Medicine </a></li>
      	<li><a href="view.php" class="w3-bar-item w3-button"> View Medicine </a></li>
      	
      </ul>
	</div>