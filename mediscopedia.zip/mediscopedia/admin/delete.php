<?php
session_start();
include "dataconnect.php";

if(isset($_POST['delete']))
{
	$query = "DELETE FROM meds where med_id >= 1 ";
	$run = mysqli_query($conn,$query);
	if($run)
	{
	
		include "del.php";
	}
	else
	{
		echo "no data is deleted from database";	
	}
}

?>