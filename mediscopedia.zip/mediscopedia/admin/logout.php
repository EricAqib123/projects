<?php

include "dataconnect.php";

if(isset($_POST['logout']))
{
	header('location:admin.php');
	exit();
}


?>