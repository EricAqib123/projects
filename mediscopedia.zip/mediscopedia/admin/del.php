<?php session_start();
 include "dataconnect.php" ?>
<!DOCTYPE html>
<html>
<head>
	<title>Delete Medicine</title>
	<link rel="stylesheet" type="text/css" href="med.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	

</head>
<body>
	<div class="logo w3-card-4 ">
      <img src="logo.png" alt="text" width="100" height="100">
      <a href="admin.php" style="text-align:center; float:right;"class="w3-bar-item w3-button w3-black"> logout </a>
	</div>
  <!--navbar-->
	 <?php include "navbar.php" ?><br>
	 <center><span class="w3-bar w3-blue"> Delete Your Saved Records</span></center>
       <div class="w3-card- w3-responsive">
         <?php 
          $query = "SELECT * from meds";
          $query_run = mysqli_query($conn,$query);
          if(mysqli_num_rows($query_run))
          {
          
          ?>

         <table class="w3-table w3-table-all w3-centered" border="1">
          <tr>
             <td>Sno</td>
            <td>Generic Name </td>
            <td>Medicine Name</td>
            <td>Medicine Age</td>
            <td>Medicine Gram</td>
            <td>Medicine Formuale</td>
            <td>Medicine Company</td>
            <td>Medicine Alternate</td>
            <td>Medicine Illness</td>
            <td>Medicine Disease</td>
            <td>Medicine Dosage</td>
            <td>Medicine Image</td>
            <td>National Drug Code</td>
            <td>Forms of Medicine/Dosage Form</td>
            <td>Route of Administration</td>
            <td>Side Effect</td>
            <td>Warnings and Precautions</td>
            <td>Contraindications</td>
            <td>Mechanism Of Action</td>
            <td>Pharmcodynamics</td>
            <td>Storage and Handling:</td>
            <td> Delete</td>
          </tr>
          <tr>
            <?php 
              while($row = mysqli_fetch_assoc($query_run))
              {
              ?>
           <td><?=$row["med_id"];?></td>
            <td><?=$row["generic_name"]; ?></td>
            <td> <?=$row["me_name"]; ?></td>
            <td><?=$row["med_age"]; ?></td>
            <td><?=$row["med_gram"]; ?></td>
            <td><?=$row["med_formuale"]; ?></td>
            <td><?=$row["med_company"]; ?></td>
            <td><?=$row["med_alt"]; ?></td>
            <td><?=$row["med_illness"]; ?></td>
            <td><?=$row["med_disease"]; ?></td>
            <td><?=$row["med_dosage"]; ?></td>
            <td><?='<img src="images/'.$row['med_image'].'" width=100 height="100" alt="image">'; ?></td>
            <td><?=$row["national_dc"]; ?></td>
            <td><?=$row["tablet"]; ?></td>
            <td><?=$row["tablet"]; ?></td>
            <td><?=$row["side_effect"]; ?></td>
            <td><?=$row["warnings"]; ?></td>
            <td><?=$row["contraind"]; ?></td>
            <td><?=$row["mechanism_action"]; ?></td>
            <td><?=$row["pharmacodynamics"]; ?></td>
            <td><?=$row["str_handle"]; ?></td>
            <td>
            	<form action="delete.php" method="post">
                 <input type="submit" name="delete"  class="w3-button w3-red" value="Delete">	
               </form>
            </td>
           </tr>
              <?php
              }
              ?>
           

           
         </table>

       </div>


</body>
</html>
<?php
}
?>