<?php
include "dataconnect.php";

if(isset($_POST["btn"]))
{
  $sno = $_POST['sno'];
  $generic_name=$_POST['generic_name']; 
  $medicine_name=$_POST['medicine_name'];
  $national_drug_code =$_POST['national_drug_code'];
  $twag = $_POST['twag'];
  $gram = $_POST['medicine_gram'];
  $formulae = $_POST['medicine_formulae'];
  $company = $_POST['medicine_company'];
  $altname = $_POST['medicine_alt'];
  $illness = $_POST['medicine_illness'];
  $disease= $_POST['medicine_disease'];
  $dosage = $_POST['medicine_dosge'];
  $tab =$_POST['anyinput'];
  $side_effect =$_POST['side_effect'];
  $warnings =$_POST['warnings'];
  $contraindications =$_POST['Contraindications'];
  $mechanism =$_POST['mechanism'];
  $str_handle = $_POST['strhandle'];
  $pharmacodynamcis = $_POST['pharmacodynamcis'];
  $image = $_FILES['upload']['name'];
  //check the fields that are empty
  if(empty($sno) or empty($generic_name) or empty($medicine_name))
  {
    //echo "fill your fields";
  }
  elseif (empty($national_drug_code) or empty($twag) or empty($gram)) {
      //echo "fill your fields";
  }
   elseif (empty($formulae) or empty($company) or empty($illness)) {
     // echo "fill your fields";
  }
   elseif (empty($disease) or empty($dosage) or empty($tab)) {
      //echo "fill your fields";
  }
  elseif (empty($side_effect) or empty($warnings) or empty($contraindications)) {
      //echo "fill your fields";
  }
  elseif (empty($mechanism) or empty($str_handle) or empty($str_handle)) {
    echo "fill your fields";
  }
  // elseif (isset($_POST['uplaod'])
  // {
  //   echo "successfully";
  // }
  else
  {

	move_uploaded_file($_FILES['medimage']['tmp_name'], "images/".$_FILES['upload']['name']);

	$q = "UPDATE meds SET med_id ='$medsno', me_name ='$medname', med_age ='$medage',med_gram ='$medgram', med_formuale ='$medformuale',med_company ='$medcomp', med_alt ='$medalt' WHERE med_id=1" ;

	$q2 = "UPDATE meds SET `med_id`='$sno',`me_name`='$medicine_name',`med_age`='$twag',`med_gram`='$gram',`med_formuale`='$formulae',`med_company`='$company',`med_alt`='$altname',`med_illness`='$illness',`med_disease`='$illness',`med_dosage`='$dosage',`med_image`='$image',`generic_name`='$generic_name',`national_dc`='$national_drug_code',`tablet`='$tab',`side_effect`='$side_effect',`warnings`='$warnings',`contraind`='$contraindications',`mechanism_action`='$mechanism',`pharmacodynamics`='$pharmacodynamics',`str_handle`='$str_handle' WHERE 1";
	$run = mysqli_query($conn,$q);
	if($run)
	{
		echo "successfully stored";
		include "update.php";
	}
	else {
  echo "Error updating record: " . $conn->error;
}


}

}


?>