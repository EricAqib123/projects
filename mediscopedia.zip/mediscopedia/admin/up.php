<?php
if(isset($_POST["btn"])) {
    $targetDir = "images/"; // Directory where uploaded files will be stored
    $targetFile = $targetDir . basename($_FILES["file"]["name"]);

  
    move_uploaded_file($_FILES['file']['tmp_name'], $targetFile);


   
}
?>
