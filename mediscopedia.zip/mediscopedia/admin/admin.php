<?php session_start();
 
 if(isset($_POST['username']))
 {
 	$username = $_POST['username'];
 	$password = $_POST['password'];
 	if($username === '' )
 	{
 		$error = 'no username';
 	}
 	elseif($password === '')
 	{
 		$error = 'no password';

 	}
 	elseif($username !== 'mediscopedia')
 	{
        $error ='username /' . $username . 'is not valid';

 	}
 	elseif($password !== '123')
 	{
 		$error = 'password is incorrect';
 	}
 	else
 	{
 		header('location:dashboard.php');
 		exit();
 	}
 }

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="med.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	

</head>
<body>
	<div class="logo w3-card-4 ">
      <img src="logo.png" alt="text" width="100" height="100">
	</div>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<?php if(isset($error)): ?>
	<h1 style="color:red"><?=$error?></h1>
<?php endif; ?>
	<form  class="w3-container" method="post">
		<center>
		 <span>Admin Panel</span> <br>
		<label> Username </label></form><br>
		<input class=" " type="text" name="username"><br>
		<label> Password </label></form><br>
		<input class=" " type="password" name="password"><br><br>
		<input class="w3-button w3-black" type="submit" name="login" value="Login">
		
        </center>
	</form>


</body>
</html>