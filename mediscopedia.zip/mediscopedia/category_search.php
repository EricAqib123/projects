<form method="POST" action="search.php">
    <input type="text" name="search" placeholder="Search...">
    <select name="category">
        <option value="">All Categories</option>
        <option value="painkiller">painkiller</option>
        <option value="Headache">Headache</option>
        <!-- Add more categories as needed -->
    </select>
    <input type="submit" value="Search" Value="Search">
</form>
